# YouTube India DPDP Prototype

This repository contains a product-thinking deck and a clickable prototype for a DPDP-ready consent and family privacy center for YouTube India.

## Prototype

Open `index.html` or `outputs/youtube-dpdp-clickable-prototype.html`.

For GitHub Pages, publish from the repository root on the `main` branch. The public prototype URL will be:

```text
https://<your-github-username>.github.io/<repo-name>/
```

## Deck

- `outputs/youtube-dpdp-product-thinking-deck.pdf`
- `outputs/youtube-dpdp-product-thinking-deck.pptx`
